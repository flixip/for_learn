from flask import Flask,jsonify,send_file
from datawashing import mon_pm25_avg,mon_pm10_avg
app = Flask(__name__)

@app.route('/')
def main():
    return send_file('E:\全栈项目实践\Visible System for Air Quality\static\index.html')
@app.route('/api/pm2.5_monthly')
def get_pm25():
    # jsonify用于转换字典为json字符串，不知道理解的对不对
    return jsonify(
        {
        'month':mon_pm25_avg.index.to_list(),   
        'pm2.5':mon_pm25_avg.round(1).to_list(),
        'pm10':mon_pm10_avg.round(1).to_list()
        }
        
    )
if __name__ == '__main__':
    app.run(debug=True)