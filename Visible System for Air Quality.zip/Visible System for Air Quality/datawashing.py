import pandas as pd
import matplotlib.pyplot as plt
# 第一步，加载数据,识别前可以略看一下需要啥
col = ['year','month','day','hour','PM2.5','PM10']
df = pd.read_csv(r'E:\全栈项目实践\Visible System for Air Quality\air_quality.csv',usecols=col)

# print(df)=>35064r * 18c
# 数据集太大，先查概况
'''
print(f"总行数：{len(df)}")
print("前3行样例：\n", df.head(3))
print("\n字段统计：\n", df.describe())'''

# 第二步 选出关键字段，时间和PM2.5，进行数据清洗

# 这里我觉得年月日分开写没必要不如合并所以合并了
df['date'] = pd.to_datetime(df[['year','month','day']])
df = df.drop(['year','day'],axis=1)
# 选中关键字找关系可以用分组求平均值的办法,这里我用日期和月份来分组
# 注意如果只进行分组，没有后续方法只能获取到一个分组对象
day_avg = df.groupby('date')[['PM2.5','PM10']].mean()
mon_avg = df.groupby('month')[['PM2.5','PM10']].mean()
mon_pm25_avg = mon_avg['PM2.5']
mon_pm10_avg = mon_avg['PM10']
# 这里可以用matplotlib.pyplot做一个简单的数据预览图
# 这种调试可以写一个只在主函数运行，避免引用的时候出错
if __name__ == '__main__':
    # mon_avg.plot(kind='bar',title='PM2.5&PM10 Monthly Average')
    # plt.show()
    # 上述的mon_avg是一个dataframe 也就是df 字典套series，变成的一个类似二维数组的东西
    # seires就是定义的一个带索引的列表，可以理解为字典但是花括号变成【】
    # 众所周知 df获取索引用.index 获取一列用df['字段名'] 获取一行用loc[index]或者iloc[index]
    # 这里发现只有索引和一个字段的时候变成了series
    print(type(mon_pm10_avg.round(1)))
    