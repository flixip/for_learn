from 遥感图像爬虫 import get_download_write 
from 遥感数据筛选处理 import filtrate
from 遥感数据提取处理 import obtain_to_database, export_csv_from_db
import os


db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': 'root',
        'database': '夜间灯光遥感数据集'
    }
mh = 'model_html\LJhtml获取模板.html'
city = '开封市'
county = '顺河回族区'
geojson = '开封市_各县级行政区划/开封市_顺河回族区.geojson'
get_download_write(mh,city,county)
filtrate(city,county,geojson)
obtain_to_database(city, county, geojson, db_config)
export_csv_from_db(db_config)