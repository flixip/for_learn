import os.path

import requests
import tarfile
from bs4 import BeautifulSoup

import shutil

headers = {
    'User-Agent':
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Cookie':
'session_cookie_name=s%3AOz0p9fM9my2qKlehVqmF7N5pQcfkaciY.vXDQ5%2B9gGomiq2%2FuPXQOKGCGZPQij%2BLUYUbSeynFU3E; user=%7B%22id%22%3A33511%2C%22code%22%3A%2215926259763%22%2C%22userName%22%3A%22%E6%96%B9%E9%A3%9E%E6%89%AC%22%2C%22pwd%22%3A%22ffy666%22%2C%22userTitle%22%3A%22%E5%AD%A6%E5%A3%AB%22%2C%22job%22%3A%22%E6%97%A0%22%2C%22workUnit%22%3A%22%E6%B2%B3%E5%8D%97%E5%A4%A7%E5%AD%A6%E5%9C%B0%E7%90%86%E4%B8%8E%E7%8E%AF%E5%A2%83%E5%AD%A6%E9%99%A2%22%2C%22major%22%3A%22%E6%B5%8B%E7%BB%98%E5%B7%A5%E7%A8%8B%22%2C%22email%22%3A%221647757673%40qq.com%22%2C%22application%22%3A%22%E7%95%A5%22%2C%22registerDate%22%3A%222024-12-16%2021%3A13%3A40%22%2C%22state%22%3A2%2C%22rid%22%3Anull%2C%22validateCode%22%3Anull%7D'
}
def get_download_write(modelhtml,city,county):
    with open(modelhtml, 'r', encoding='utf-8')as f:
        text = f.read()
    soup = BeautifulSoup(text, 'html.parser')
    e_tr = soup.find_all('tr')
    dic = {}
    index = 0
    # 创建持久化存储目录（确保后续处理可用）
    save_dir = f'卫星文件解压目录/{city}{county}'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    for e_td in e_tr:
        td = e_td.find_all('td')
        date = td[4].text
        link = 'http://59.175.109.173:8888' + td[5].find_all('a')[1].get('href')
        resp = requests.get(link,timeout=10,headers=headers)
        
        file_name = f'卫星文件保存目录/{city}{county}/LJ{index}.tar.gz'
        if not os.path.exists(file_name):
            if not os.path.exists(f'卫星文件保存目录/{city}{county}'):
                os.makedirs(f'卫星文件保存目录/{city}{county}')
            
            # 下载完成后立即删除压缩包
            with open(file_name, 'wb')as f:
                f.write(resp.content)
                print(f'第{index + 1}个文件，下载完毕！！')
            
            # 解压完成后删除压缩包和解压目录
            try:
                with tarfile.open(file_name, 'r:gz') as f:
                    # 修改解压路径为持久化目录
                    extract_path = os.path.join(save_dir, f'LJ{index}')
                    f.extractall(extract_path)
            finally:
                os.remove(file_name)  # 仅删除压缩包
                
            index += 1
    
    # 在爬取完成后添加（新增）
    shutil.rmtree(f'卫星文件保存目录/{city}{county}')
    print(f'已清理保存目录: 卫星文件保存目录/{city}{county}')
    
    # 新增：处理完成后保留解压目录
    print(f"所有文件已持久化存储至: {save_dir}")

if __name__ == '__main__':
    get_download_write('LJhtml获取模板.html','开封市','龙亭区')