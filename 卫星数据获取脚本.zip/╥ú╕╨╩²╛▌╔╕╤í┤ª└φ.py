import os
import shutil
from osgeo import gdal, ogr


def get_image_extent(image_path):
    dataset = gdal.Open(image_path)
    if dataset is None:
        print('无法打开图像文件')
        return None, None, None, None

    width = dataset.RasterXSize
    height = dataset.RasterYSize
    geotransform = dataset.GetGeoTransform()
    if geotransform:
        left = geotransform[0]
        top = geotransform[3]
        right = left + width * geotransform[1] + height * geotransform[2]
        bottom = top + width * geotransform[4] + height * geotransform[5]
        dataset = None
        return left, top, right, bottom
    dataset = None
    return None, None, None, None


def get_extremes(geojson_path):
    ogr.RegisterAll()
    ds = ogr.Open(geojson_path)
    if ds is None:
        print(f"无法打开 {geojson_path}")
        return None, None, None, None

    layer = ds.GetLayer(0)
    if layer is None:
        print("无法获取图层")
        ds = None
        return None, None, None, None

    leftmost = float('inf')
    topmost = float('-inf')
    rightmost = float('-inf')
    bottommost = float('inf')

    for feature in layer:
        geometry = feature.GetGeometryRef()
        if geometry is not None:
            min_x, max_x, min_y, max_y = geometry.GetEnvelope()
            if min_x < leftmost:
                leftmost = min_x
            if max_y > topmost:
                topmost = max_y
            if max_x > rightmost:
                rightmost = max_x
            if min_y < bottommost:
                bottommost = min_y

    ds = None
    return leftmost, topmost, rightmost, bottommost


def check_coverage(image_path, geojson_path):
    image_left, image_top, image_right, image_bottom = get_image_extent(image_path)
    geo_left, geo_top, geo_right, geo_bottom = get_extremes(geojson_path)

    if image_left is None or geo_left is None:
        return False

    # 判断影像是否覆盖行政区划
    return (image_left <= geo_left and
            image_top >= geo_top and
            image_right >= geo_right and
            image_bottom <= geo_bottom)


# 示例调用
def filtrate(city, county, geojson_file):
    image_file_list = []
    for i in os.listdir(f'卫星文件解压目录/{city}{county}'):
        j = f'卫星文件解压目录/{city}{county}/{i}/' + os.listdir(f'卫星文件解压目录/{city}{county}/{i}')[0]
        image_file_list.append(j)
    index = 0
    c = 0
    for image_file in image_file_list:
        index += 1
        is_covered = check_coverage(image_file, geojson_file)
        if is_covered:
            c += 1
            def copy_file_to_folder(source_file, destination_folder):
                try:
                    # 检查目标文件夹是否存在，如果不存在则创建
                    if not os.path.exists(destination_folder):
                        os.makedirs(destination_folder)
                    # 复制文件到目标文件夹
                    shutil.copy2(source_file, destination_folder)
                    print(f"文件 {source_file} 已成功复制到 {destination_folder}")
                except FileNotFoundError:
                    print(f"错误：源文件 {source_file} 未找到。")
                except PermissionError:
                    print(f"错误：没有权限复制文件到 {destination_folder}。")
                except Exception as e:
                    print(f"发生未知错误：{e}")


            # 示例调用
            source_file = image_file
            destination_folder = f'卫星文件裁剪目录/{city}{county}'
            copy_file_to_folder(source_file, destination_folder)
            print(f'成功复制{c}张影像')
        else:
            print("遥感影像未覆盖整个行政区划。")
    print(f'成功处理{index}张影像')
if __name__ == '__main__':
    filtrate('开封市','龙亭区','开封市_各县级行政区划\开封市_龙亭区.geojson')