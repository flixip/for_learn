import os
import datetime
import csv
from osgeo import gdal, ogr
import numpy as np

# 在文件顶部添加导入
import mysql.connector
from mysql.connector import Error
import shutil


def calculate_night_light_mean(input_raster_path, geojson_path):
    # 创建临时文件路径
    temp_output = "temp_cropped.tif"
    
    warp_options = gdal.WarpOptions(
        cutlineDSName=geojson_path,
        cropToCutline=True,
        dstNodata=0,
        options=['-overwrite']
    )
    
    try:
        # 先写入临时文件
        gdal.Warp(temp_output, input_raster_path, options=warp_options)
        
        # 关闭原文件句柄
        if os.path.exists(input_raster_path):
            os.remove(input_raster_path)
        
        # 重命名临时文件
        os.rename(temp_output, input_raster_path)

        # 读取已重命名的文件
        ds = gdal.Open(input_raster_path)
        band = ds.GetRasterBand(1)
        data = band.ReadAsArray()

        # 添加空数据检查
        valid_mask = data > 0
        if np.sum(valid_mask) == 0:
            print(f"警告：{input_raster_path} 无有效数据")
            return 0.0, 0.0

        dn_values = data[valid_mask]
        radiance = np.power(dn_values, 3 / 2) * 10 ** (-10)
        
        mean_radiance = np.mean(radiance)
        max_radiance = np.max(radiance)
        return mean_radiance, max_radiance
        
    except Exception as e:
        print(f"处理文件 {input_raster_path} 时发生错误: {str(e)}")
        return 0.0, 0.0
    finally:
        # 清理残留临时文件
        if os.path.exists(temp_output):
            os.remove(temp_output)


def obtain_to_database(city, county, geojson, db_config):
    """专门处理数据库存储"""
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        # 创建表（如果不存在）
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS night_light_data (
                id INT AUTO_INCREMENT PRIMARY KEY,
                record_time DATETIME NOT NULL,
                mean_radiance FLOAT NOT NULL,
                max_radiance FLOAT NOT NULL,
                location VARCHAR(100) NOT NULL,
                image_data LONGBLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        for i in os.listdir(f'卫星文件裁剪目录/{city}{county}'):
            if i.endswith('.tif'):
                # 处理时间解析和图像裁剪
                datetime_obj = datetime.datetime.strptime(i.split('_')[2], "%Y%m%d%H%M%S")
                input_raster = f'卫星文件裁剪目录/{city}{county}/{i}'
                mean, max_val = calculate_night_light_mean(input_raster, geojson)
                
                # 插入数据库
                with open(input_raster, 'rb') as f:
                    cursor.execute("""
                        INSERT INTO night_light_data 
                        (record_time, mean_radiance, max_radiance, location, image_data)
                        VALUES (%s, %s, %s, %s, %s)
                        """, (datetime_obj, mean, max_val, f'{city}{county}', f.read()))
                    conn.commit()
                
                # 新增：插入成功后立即删除裁剪文件
                if os.path.exists(input_raster):
                    os.remove(input_raster)
                    print(f'已清理临时文件: {input_raster}')
        
        # 删除裁剪目录（新增）
        shutil.rmtree(f'卫星文件裁剪目录/{city}{county}')
        print(f'已清理裁剪目录: 卫星文件裁剪目录/{city}{county}')

        # 删除解压目录（已有代码）
        shutil.rmtree(f'卫星文件解压目录/{city}{county}') 
        print(f'已清理解压目录: 卫星文件解压目录/{city}{county}')

    except Error as e:
        print(f"数据库操作失败: {str(e)}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

def export_csv_from_db(db_config, output_file='night_light_data.csv'):
    """从数据库导出CSV"""
    conn = None
    cursor = None  # 初始化变量
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT record_time, mean_radiance, max_radiance, location 
            FROM night_light_data
            ORDER BY record_time
        """)
        
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['记录时间', '平均辐射值', '最大辐射值', '地区'])
            
            for row in cursor.fetchall():
                writer.writerow([
                    row['record_time'].strftime("%Y-%m-%d %H:%M:%S"),
                    row['mean_radiance'],
                    row['max_radiance'],
                    row['location']
                ])
        print(f'CSV文件已生成: {output_file}')
        
    except Exception as e:  # 修改为捕获通用异常
        print(f"数据库导出失败: {str(e)}")
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()


if __name__ == "__main__":
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': 'root',
        'database': '夜间灯光遥感数据集'
    }
    obtain_to_database('开封市', '龙亭区', '开封市_各县级行政区划\开封市_龙亭区.geojson', db_config)
    export_csv_from_db(db_config)